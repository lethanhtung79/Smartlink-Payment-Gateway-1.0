﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;

namespace dotNET_Merchant
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //  Merchant Secret Key
            string SECRET_KEY = System.Configuration.ConfigurationManager.AppSettings["SECRET_KEY"].ToString();

            //  Ví dụ này gửi lên tất cả các field trong tài liệu mô tả.
            //  Thực tế, những field nào không có giá trị, sẽ không truyền lên cổng thanh toán!
            string data = string.Format("vpc_Version={0}&vpc_Command={1}&vpc_Currency={2}&vpc_AccessCode={3}&vpc_MerchTxnRef={4}&vpc_Merchant={5}&vpc_OrderInfo={6}&vpc_Amount={7}&vpc_Locale={8}&vpc_ReturnURL={9}&vpc_TicketNo={10}",
                Server.UrlEncode(vpc_Version.Text.Trim()),
                Server.UrlEncode(vpc_Command.Text.Trim()),
                Server.UrlEncode(vpc_Currency.Text.Trim()),
                Server.UrlEncode(vpc_AccessCode.Text.Trim()),
                Server.UrlEncode(vpc_MerchTxnRef.Text.Trim()),
                Server.UrlEncode(vpc_Merchant.Text.Trim()),
                Server.UrlEncode(vpc_OrderInfo.Text.Trim()),
                Server.UrlEncode(vpc_Amount.Text.Trim()),
                Server.UrlEncode(vpc_Locale.Text.Trim()),
                Server.UrlEncode(vpc_ReturnURL.Text.Trim()),
                Server.UrlEncode(vpc_TicketNo.Text.Trim()) 
                );

            //  Tính toán checksum theo thứ tự sắp xếp ABC các field gửi lên cổng thanh toán.
            string md5input = SECRET_KEY 
                + vpc_AccessCode.Text.Trim() 
                + vpc_Amount.Text.Trim() 
                + vpc_Command.Text.Trim()
                + vpc_Currency.Text.Trim()
                + vpc_Locale.Text.Trim()
                + vpc_MerchTxnRef.Text.Trim()
                + vpc_Merchant.Text.Trim()
                + vpc_OrderInfo.Text.Trim()
                + vpc_ReturnURL.Text.Trim()
                + vpc_TicketNo.Text.Trim()
                + vpc_Version.Text.Trim();

            Byte[] originalBytes;
            StringBuilder sb = new StringBuilder();
            MD5 md5 = new MD5CryptoServiceProvider();

            originalBytes = UTF8Encoding.UTF8.GetBytes(md5input);

            foreach (Byte b in md5.ComputeHash(originalBytes))
                sb.Append(b.ToString("x2").ToUpper());

            string checksum = sb.ToString();

            string strRedirectURL = string.Format("{0}?{1}&vpc_SecureHash={2}",
                virtualPaymentClientURL.Text.Trim(),
                data,
                checksum);

            Response.Redirect(strRedirectURL);
        }
    }
}
