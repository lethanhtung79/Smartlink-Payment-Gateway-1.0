﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;

namespace dotNET_Merchant
{
    public partial class OrderResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string SECRET_KEY = System.Configuration.ConfigurationManager.AppSettings["SECRET_KEY"].ToString();
            string strSecureHash = (Request.QueryString["vpc_SecureHash"] != null) ? Server.UrlDecode(Request.QueryString["vpc_SecureHash"].ToUpper()) : "";

            vpc_Version.Text = (Request.QueryString["vpc_Version"] != null) ? Server.UrlDecode(Request.QueryString["vpc_Version"]) : "";
            vpc_Command.Text = (Request.QueryString["vpc_Command"] != null) ? Server.UrlDecode(Request.QueryString["vpc_Command"]) : "";
            vpc_Locale.Text = (Request.QueryString["vpc_Locale"] != null) ? Server.UrlDecode(Request.QueryString["vpc_Locale"]) : "";
            vpc_Merchant.Text = (Request.QueryString["vpc_Merchant"] != null) ? Server.UrlDecode(Request.QueryString["vpc_Merchant"]) : "";
            vpc_MerchTxnRef.Text = (Request.QueryString["vpc_MerchTxnRef"] != null) ? Server.UrlDecode(Request.QueryString["vpc_MerchTxnRef"]) : "";
            vpc_Amount.Text = (Request.QueryString["vpc_Amount"] != null) ? Server.UrlDecode(Request.QueryString["vpc_Amount"]) : "";
            vpc_ResponseCode.Text = (Request.QueryString["vpc_ResponseCode"] != null) ? Server.UrlDecode(Request.QueryString["vpc_ResponseCode"]) : "";
            vpc_TransactionNo.Text = (Request.QueryString["vpc_TransactionNo"] != null) ? Server.UrlDecode(Request.QueryString["vpc_TransactionNo"]) : "";
            vpc_OrderInfo.Text = (Request.QueryString["vpc_OrderInfo"] != null) ? Server.UrlDecode(Request.QueryString["vpc_OrderInfo"]) : "";
            vpc_CurrencyCode.Text = (Request.QueryString["vpc_CurrencyCode"] != null) ? Server.UrlDecode(Request.QueryString["vpc_CurrencyCode"]) : "";

            vpc_AcqResponseCode.Text = (Request.QueryString["vpc_AcqResponseCode"] != null) ? Server.UrlDecode(Request.QueryString["vpc_AcqResponseCode"]) : "";
            vpc_AdditionalData.Text = (Request.QueryString["vpc_AdditionalData"] != null) ? Server.UrlDecode(Request.QueryString["vpc_AdditionalData"]) : "";
            vpc_Message.Text = (Request.QueryString["vpc_Message"] != null) ? Server.UrlDecode(Request.QueryString["vpc_Message"]) : "";
            vpc_CardType.Text = (Request.QueryString["vpc_CardType"] != null) ? Server.UrlDecode(Request.QueryString["vpc_CardType"]) : "";
            vpc_BatchNo.Text = (Request.QueryString["vpc_BatchNo"] != null) ? Server.UrlDecode(Request.QueryString["vpc_BatchNo"]) : "";

            string md5input = SECRET_KEY
                + vpc_AcqResponseCode.Text
                + vpc_AdditionalData.Text
                + vpc_Amount.Text
                + vpc_BatchNo.Text
                + vpc_CardType.Text
                + vpc_Command.Text
                + vpc_CurrencyCode.Text
                + vpc_Locale.Text
                + vpc_MerchTxnRef.Text
                + vpc_Merchant.Text
                + vpc_Message.Text
                + vpc_OrderInfo.Text
                + vpc_ResponseCode.Text
                + vpc_TransactionNo.Text
                + vpc_Version.Text;

            Byte[] originalBytes;
            StringBuilder sb = new StringBuilder();
            MD5 md5 = new MD5CryptoServiceProvider();

            originalBytes = ASCIIEncoding.Default.GetBytes(md5input);

            foreach (Byte b in md5.ComputeHash(originalBytes))
                sb.Append(b.ToString("x2").ToUpper());

            string checksum = sb.ToString();

            if (strSecureHash.Length > 0)
            {
                if (checksum.Equals(strSecureHash))
                {
                    vpc_SecureHash.Text = strSecureHash + " - CORRECT";
                }
                else
                {
                    vpc_SecureHash.Text = strSecureHash + " - INCORRECT";
                }
            }
        }
    }
}
